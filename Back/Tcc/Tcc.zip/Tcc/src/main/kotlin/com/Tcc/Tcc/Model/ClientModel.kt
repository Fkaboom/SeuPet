package com.Tcc.Tcc.Model

import org.bson.types.ObjectId
import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import org.springframework.data.mongodb.core.mapping.Field
import java.util.*

@Document("cliente")
data class ClienteModel(
    @Id
    val id: ObjectId = ObjectId(),
    val email: String,
    val pwd: String ,
    val number: String,
    @Field("cliente_id")
    val clienteId: String = id.timestamp.toString()
)



