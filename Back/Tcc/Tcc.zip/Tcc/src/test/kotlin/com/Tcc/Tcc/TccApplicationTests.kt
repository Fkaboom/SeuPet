package com.Tcc.Tcc

import com.Tcc.Tcc.Model.ClienteModel
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TccApplicationTests {

	@Test
	fun contextLoads() {
	}

	private val END_POINT_PATH = "/users"


}
