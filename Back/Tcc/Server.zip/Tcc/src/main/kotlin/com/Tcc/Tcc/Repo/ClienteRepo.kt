package com.Tcc.Tcc.Repo

import com.Tcc.Tcc.Model.ClienteModel
import org.springframework.data.mongodb.repository.MongoRepository

interface ClienteRepo : MongoRepository<ClienteModel, String> {

    fun findByClienteId(clienteId: String): ClienteModel?
    fun findByEmail(email: String): ClienteModel?
    fun findByEmailAndPwd(email: String, pwd: String): ClienteModel?

}