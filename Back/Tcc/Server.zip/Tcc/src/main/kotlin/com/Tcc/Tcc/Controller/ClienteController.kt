package com.Tcc.Tcc.Controller




import com.Tcc.Tcc.Repo.ClienteRepo
import com.Tcc.Tcc.Model.ClienteModel
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.util.*

@RestController
@RequestMapping("/cliente")
class ClienteController(@Autowired val clienteRepo: ClienteRepo) {



    @GetMapping("/all")
    fun getCount(): ResponseEntity<MutableList<ClienteModel>> {
        val cliente = clienteRepo.findAll()
        return if (cliente != null) ResponseEntity.ok(cliente) else ResponseEntity
            .notFound().build()
    }

    @GetMapping("/{id}")
    fun getClienteById(@PathVariable("id") id: String): ResponseEntity<ClienteModel> {
        val cliente = clienteRepo.findByClienteId(id)
        return if (cliente != null) ResponseEntity.ok(cliente) else ResponseEntity
            .notFound().build()
    }

    @GetMapping("/{email}")
    fun getClienteByEmail(@PathVariable("email") email: String): ResponseEntity<ClienteModel> {
        val cliente = clienteRepo.findByEmail(email)
        return if (cliente != null) ResponseEntity.ok(cliente) else ResponseEntity
            .notFound().build()
    }

    @GetMapping("/login")
    fun login(@RequestParam email: String,pwd: String ) : ResponseEntity<ClienteModel> {
        val cliente = clienteRepo.findByEmailAndPwd(email,pwd)
        return if (cliente != null) ResponseEntity.ok(cliente) else ResponseEntity
            .notFound().build()
    }


    @PostMapping("/insert")
    fun postCliente(@RequestBody cliente: ClienteModel): ClienteModel {
        return clienteRepo.insert(cliente)
    }


    @DeleteMapping("/{id}")
    fun deleteCliente(@PathVariable("id") id: String) {
        clienteRepo.findByClienteId(id)?.let {
            clienteRepo.delete(it)
        }
    }


}